import React, { Component } from "react";

class About extends Component {
  
}

export default About;
