
class Footer extends Component {
  
}

export default Footer;
