class Home extends Component {

}

export default Home;
