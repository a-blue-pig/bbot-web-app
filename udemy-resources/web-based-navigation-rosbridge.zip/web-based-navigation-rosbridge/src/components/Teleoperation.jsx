class Teleoperation extends Component {
  
}

export default Teleoperation;
